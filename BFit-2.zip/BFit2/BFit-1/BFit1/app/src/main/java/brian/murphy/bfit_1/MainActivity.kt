package brian.murphy.bfit_1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import brian.murphy.bfit_1.databinding.ActivityMainBinding
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private val diaryEntries= mutableListOf<DisplayDiary>()
    private lateinit var diaryRecyclerView: RecyclerView
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding=ActivityMainBinding.inflate(layoutInflater)
        val view=binding.root
        // setContentView(R.layout.activity_main)
        setContentView(view)

        // Define adapter

        diaryRecyclerView = findViewById(R.id.diary_entries)
        val diaryAdapter = DiaryAdapter(this, diaryEntries)
        diaryRecyclerView.adapter = diaryAdapter
        diaryRecyclerView.layoutManager = LinearLayoutManager(this).also {
            val dividerItemDecoration = DividerItemDecoration(this, it.orientation)
            diaryRecyclerView.addItemDecoration(dividerItemDecoration)
        }

        // Populate with data

        lifecycleScope.launch {
            (application as DiaryApplication).db.diaryDao().getAll().collect { databaseList ->
                databaseList.map { entity ->
                    DisplayDiary(
                        entity.title,
                        entity.text,
                        entity.date
                    )
                }.also { mappedList ->
                    diaryEntries.clear()
                    diaryEntries.addAll(mappedList)
                    diaryAdapter.notifyDataSetChanged()
                }
            }
        }



        val goToAddEntryScreen= findViewById<Button>(R.id.goTo_add_entry)

        goToAddEntryScreen.setOnClickListener {
            // Send back to add Entry Screen screen
            val intent= Intent(applicationContext,addEntryActivity::class.java)
            startActivity(intent)
        }


    }
}