package brian.murphy.bfit_1

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers.IO
import kotlinx.coroutines.launch

// Add item to the DB
class addEntryActivity :AppCompatActivity(){
    private lateinit var dateEditText:TextView
    private lateinit var titleEditText: TextView
    private lateinit var textEditText:TextView
    private lateinit var addBtn: Button

    override fun onCreate( savedInstanceState: Bundle?){
        super.onCreate(savedInstanceState)
        setContentView(R.layout.add_entry)

        addBtn=findViewById<Button>(R.id.add_entry)

        dateEditText=findViewById<TextView>(R.id.add_date)
        titleEditText=findViewById<TextView>(R.id.add_title)
        textEditText=findViewById<TextView>(R.id.add_text)

        addBtn.setOnClickListener(){
            var dDate=dateEditText.text.toString()
            var dTitle= titleEditText.text.toString()
            var dTet=textEditText.text.toString()
            lifecycleScope.launch(IO){
                (application as DiaryApplication).db.diaryDao().insertOne(
                    DiaryEntity(dTitle,dTet,dDate)
                )
            }

            // Send back to main screen
            val intent=Intent(applicationContext,MainActivity::class.java)
            startActivity(intent)
        }

    }
}