package brian.murphy.bfit_1

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.*

@Entity(tableName = "diary_table")
data class DiaryEntity(

    @ColumnInfo(name="title") val title:String?,
    @ColumnInfo(name="text") val text:String?,
    @ColumnInfo(name="date") val date: String?,
    @PrimaryKey(autoGenerate = true) val id: Long=0
    )

@Entity(tableName = "mood_table")
data class MoodEntity(
    @PrimaryKey(autoGenerate = true) val id:Long=0,
    @ColumnInfo(name="mood") val mood:String?,
    @ColumnInfo(name="date") val date:Date?
)