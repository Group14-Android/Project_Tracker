package brian.murphy.bfit_1

import java.util.*

/*
    @ColumnInfo(name="title") val title:String?,
    @ColumnInfo(name="text") val text:String?,
    @ColumnInfo(name="date") val date: Date?
* */
data class DisplayDiary(
    val title:String?,
    val text:String?,
    val date: String?
) :java.io.Serializable
