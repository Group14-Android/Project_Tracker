package brian.murphy.bfit_1

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import org.w3c.dom.Text

const val DIARY_EXTRA="DIARY_EXTRA"

class DiaryAdapter(
    private val context: Context,
    private val diaries:List<DisplayDiary>):
        RecyclerView.Adapter<DiaryAdapter.ViewHolder>(){


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view=LayoutInflater.from(context).inflate(R.layout.diary_entry,parent,false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val diary_entry=diaries[position]
        holder.bind(diary_entry)
    }

    override fun getItemCount(): Int {
        return diaries.size
    }
    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView),
        View.OnClickListener{
        private val dateTextView=itemView.findViewById<TextView>(R.id.display_date)
        private val titleTextView=itemView.findViewById<TextView>(R.id.display_title)
        private val entryTextView=itemView.findViewById<TextView>(R.id.display_entry)

        init{
            itemView.setOnClickListener(this)
        }
        fun  bind(diary_entry: DisplayDiary){
            dateTextView.text= diary_entry.date.toString()
            titleTextView.text= diary_entry.title
            entryTextView.text=diary_entry.text


        }
        /*val goToAddEntryScreen= findViewById<Button>(R.id.goTo_add_entry)

        goToAddEntryScreen.setOnClickListener {
            // Send back to add Entry Screen screen
            val intent= Intent(applicationContext,addEntryActivity::class.java)
            startActivity(intent)
        }*/

        override fun onClick(v: View?) {
            Toast.makeText(context, "Test",Toast.LENGTH_SHORT)
        }

    }

}
