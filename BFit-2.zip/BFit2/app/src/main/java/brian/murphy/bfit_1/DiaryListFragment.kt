package brian.murphy.bfit_1

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.launch


class DiaryListFragment : Fragment() {
    private val diaryEntries= mutableListOf<DisplayDiary>()

    // Set the recyclerview and adapter for it
    private lateinit var diaryRecView: RecyclerView
    private lateinit var diaryAdapter: DiaryAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        fetchDiaryEntries()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view= inflater.inflate(R.layout.fragment_diary_list, container, false)
        // Configure the adapter and the layout for it
        diaryRecView=view.findViewById<RecyclerView>(R.id.list)
        diaryRecView.layoutManager=LinearLayoutManager(context)
        diaryRecView.setHasFixedSize(true)
        diaryAdapter= DiaryAdapter(view.context,diaryEntries)
        diaryRecView.adapter=diaryAdapter
        //fetchDiaryEntries()

        val goToAddEntryScreen= view.findViewById<Button>(R.id.goTo_add_entry)


        goToAddEntryScreen.setOnClickListener {
            // Send back to add Entry Screen screen
            val intent= Intent(activity,addEntryActivity::class.java)
            startActivity(intent)
        }

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        //fetchDiaryEntries()
    }

    private fun fetchDiaryEntries() {
        // Populate with data
        lifecycleScope.launch {
            val application= DiaryApplication()
            application.db.diaryDao().getAll().collect { databaseList ->
                databaseList.map { entity ->
                    DisplayDiary(
                        entity.title,
                        entity.text,
                        entity.date,
                        entity.mood
                    )
                }.also { mappedList ->
                    diaryEntries.clear()
                    diaryEntries.addAll(mappedList)
                    diaryAdapter.notifyDataSetChanged()
                }
            }
        }


    }

    companion object{
        fun newInstance(): DiaryListFragment{
            return DiaryListFragment()
        }
    }



}