package brian.murphy.bfit_1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import brian.murphy.bfit_1.databinding.ActivityMainBinding
import com.google.android.material.bottomnavigation.BottomNavigationView
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private val diaryEntries= mutableListOf<DisplayDiary>()
    private lateinit var diaryRecyclerView: RecyclerView
    private lateinit var binding: ActivityMainBinding
    private lateinit var dao: DiaryDao

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        // setContentView(R.layout.activity_main)
        setContentView(view)


        val diaryAdapter = DiaryAdapter(this, diaryEntries)



        // Populate with data

        lifecycleScope.launch {
            (application as DiaryApplication).db.diaryDao().getAll().collect { databaseList ->
                databaseList.map { entity ->
                    DisplayDiary(
                        entity.title,
                        entity.text,
                        entity.date,
                        entity.mood
                    )
                }.also { mappedList ->
                    diaryEntries.clear()
                    diaryEntries.addAll(mappedList)
                    diaryAdapter.notifyDataSetChanged()
                }
            }
        }

        val fragmentManager: FragmentManager = supportFragmentManager
        val bottomNavigationBar: BottomNavigationView =findViewById(R.id.bottom_navigation)
        bottomNavigationBar.setOnItemReselectedListener { item->
            lateinit var fragment: Fragment
            when (item.itemId){
                R.id.action_diary -> fragment =DiaryListFragment()
                R.id.action_mood->fragment =DiarySummary()
            }
            replaceFragment(fragment)
            true
        }
        bottomNavigationBar.selectedItemId=R.id.action_diary
    }

    private fun replaceFragment(fragment: Fragment) {
        val fragmentManager=supportFragmentManager
        val fragmentTransaction= fragmentManager.beginTransaction()
        fragmentTransaction.replace(R.id.current_frame_layout,fragment)
        fragmentTransaction.commit()

    }



    // Define adapter
    /*
        diaryRecyclerView = findViewById(R.id.diary_entries)
        val diaryAdapter = DiaryAdapter(this, diaryEntries)
        diaryRecyclerView.adapter = diaryAdapter
        diaryRecyclerView.layoutManager = LinearLayoutManager(this).also {
            val dividerItemDecoration = DividerItemDecoration(this, it.orientation)
            diaryRecyclerView.addItemDecoration(dividerItemDecoration)
        }

        // Populate with data

        lifecycleScope.launch {
            (application as DiaryApplication).db.diaryDao().getAll().collect { databaseList ->
                databaseList.map { entity ->
                    DisplayDiary(
                        entity.title,
                        entity.text,
                        entity.date
                    )
                }.also { mappedList ->
                    diaryEntries.clear()
                    diaryEntries.addAll(mappedList)
                    diaryAdapter.notifyDataSetChanged()
                }
            }
        }

        val goToAddEntryScreen= findViewById<Button>(R.id.goTo_add_entry)

        goToAddEntryScreen.setOnClickListener {
            // Send back to add Entry Screen screen
            val intent= Intent(applicationContext,addEntryActivity::class.java)
            startActivity(intent)
        }




    }*/
}