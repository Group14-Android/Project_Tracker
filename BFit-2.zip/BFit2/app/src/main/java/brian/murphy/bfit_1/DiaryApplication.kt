package brian.murphy.bfit_1

import android.app.Application

// First code run by Android Studio
class DiaryApplication:Application(){
    val db by lazy{ AppDatabase.getInstance(this)}
}