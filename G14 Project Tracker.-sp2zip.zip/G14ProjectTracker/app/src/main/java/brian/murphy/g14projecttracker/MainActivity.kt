package brian.murphy.g14projecttracker

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.RecyclerView
import brian.murphy.g14projecttracker.databinding.ActivityMainBinding
import com.google.android.material.bottomnavigation.BottomNavigationView
import kotlinx.coroutines.flow.collect

import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private val projectEntries= mutableListOf<DisplayProject>()
    private lateinit var projectRecyclerView: RecyclerView
    private lateinit var binding: ActivityMainBinding
    private lateinit var prodao: ProjectDao
    //private lateinit var notedao:NotesDao
    //private lateinit var resdao:ResourcesDao

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val projectAdapter=ProjectAdapter(this, projectEntries)
        // Activate DB
        lifecycleScope.launch {
            (application as ProjectApplication).db.projDao().getAll().collect {
                databaseList-> databaseList.map { projectEntity ->DisplayProject(
                projectEntity.title,
                projectEntity.summary,
                projectEntity.description,
                projectEntity.tasks,
                projectEntity.num_remainingTasks,
                projectEntity.num_totalTasks,
                projectEntity.startDate)
                }.also { mappedList ->
                projectEntries.clear()
                projectEntries.addAll(mappedList)
                projectAdapter.notifyDataSetChanged()
            }
            }
        }

        val fragmentManager: FragmentManager = supportFragmentManager
        val bottomNavigationBar: BottomNavigationView =findViewById(R.id.bottom_navigation)
        bottomNavigationBar.setOnItemReselectedListener { item->
            lateinit var fragment: Fragment
            when (item.itemId){
                R.id.action_listProjects -> fragment =ProjectList()
                R.id.action_newProject->fragment =NewProject()
            }
            replaceFragment(fragment)
            true
        }
        bottomNavigationBar.selectedItemId=R.id.action_listProjects
    }

    private fun replaceFragment(fragment: Fragment) {
        val fragmentManager=supportFragmentManager
        val fragmentTransaction= fragmentManager.beginTransaction()
        fragmentTransaction.replace(R.id.current_frame_layout,fragment)
        fragmentTransaction.commit()

    }


}