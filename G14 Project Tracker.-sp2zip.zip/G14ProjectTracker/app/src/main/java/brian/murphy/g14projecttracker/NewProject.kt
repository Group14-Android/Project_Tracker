package brian.murphy.g14projecttracker

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Dispatchers.IO
import kotlinx.coroutines.launch

class NewProject : Fragment() {
    private lateinit var proj_TitleEditText: TextView
    private lateinit var proj_summaryET: TextView
    private lateinit var proj_descet:TextView
    private lateinit var proj_TaskListed:TextView
    private lateinit var proj_NumTasks:TextView
    private lateinit var proj_start:TextView
    private lateinit var addProj:Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view= inflater.inflate(R.layout.new_project, container, false)
        proj_TitleEditText=view.findViewById(R.id.addtitle)
        proj_summaryET=view.findViewById(R.id.addSummary)
        proj_descet=view.findViewById(R.id.adddescription)
        proj_TaskListed=view.findViewById(R.id.addtaskList)
        proj_NumTasks=view.findViewById(R.id.addnumTasks)
        proj_start=view.findViewById(R.id.addstartdate)


        addProj=view.findViewById(R.id.add_project)
        addProj.setOnClickListener(){
            var ptitle=proj_TitleEditText.text.toString()
            var pSumm=proj_summaryET.text.toString()
            var pDescr=proj_descet.text.toString()
            var ptaskList=proj_TaskListed.text.toString()
            var pNumtasks=proj_NumTasks.text.toString().toInt()
            var pStart=proj_start.text.toString()
            lifecycleScope.launch(IO) {
                val application=ProjectApplication()
                application.db.projDao().insertOne(
                    ProjectEntity(ptitle,pSumm,pDescr,ptaskList,pNumtasks,pNumtasks,pStart)
                )
            }
            // Send back
            parentFragmentManager.popBackStackImmediate()
        }
        return view


    }


}