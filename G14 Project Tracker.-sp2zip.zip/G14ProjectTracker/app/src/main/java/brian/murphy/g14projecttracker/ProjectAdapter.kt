package brian.murphy.g14projecttracker

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView

const val PROJECT_EXTRA="PROJ_EXTRA"

// Adapter for Recyclerview items
class ProjectAdapter(
    private val context: Context,
    private val Projects:List<DisplayProject>):
    RecyclerView.Adapter<ProjectAdapter.ViewHolder>(){

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view= LayoutInflater.from(context).inflate(R.layout.project_entry,parent,false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val project=Projects[position]
        holder.bind(project)
    }

    override fun getItemCount(): Int {
        return Projects.size
    }

    // Holds the view
    inner class ViewHolder(itemView: View): RecyclerView.ViewHolder(itemView), View.OnClickListener{
        private val projTitle_tv=itemView.findViewById<TextView>(R.id.prj_title)
        private val projSummary_tv=itemView.findViewById<TextView>(R.id.prj_summary)
        private val projDate_tv=itemView.findViewById<TextView>(R.id.prj_started)
        init{
            itemView.setOnClickListener(this)
        }
        fun bind(proj:DisplayProject){
            projTitle_tv.text=proj.title.toString()
            projSummary_tv.text=proj.summary
            projDate_tv.text=proj.startDate
        }

        override fun onClick(v: View?) {
            Toast.makeText(context,"TODO",Toast.LENGTH_SHORT)
        }
    }

}