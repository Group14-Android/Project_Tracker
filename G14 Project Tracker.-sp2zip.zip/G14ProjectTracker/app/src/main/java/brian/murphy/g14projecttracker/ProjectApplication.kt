package brian.murphy.g14projecttracker

import android.app.Application

class ProjectApplication: Application() {
    val db by lazy { AppDatabase.getInstance(this) }
}