package brian.murphy.g14projecttracker

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

class ProjectList : Fragment() {
    private val projectEntries= mutableListOf<DisplayProject>()

    private lateinit var projectRecView: RecyclerView
    private lateinit var projectAdapter: ProjectAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        fetchProjectEntries()

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view= inflater.inflate(R.layout.project_list_fragment, container, false)

        projectRecView=view.findViewById<RecyclerView>(R.id.project_list)
        projectRecView.layoutManager=LinearLayoutManager(context)
        projectRecView.setHasFixedSize(false)
        projectAdapter= ProjectAdapter(view.context,projectEntries)
        projectRecView.adapter=projectAdapter

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
    }

    private fun fetchProjectEntries(){
        lifecycleScope.launch {
            val application=ProjectApplication()
            application.db.projDao().getAll().collect{
                    databaseList-> databaseList.map { projectEntity ->DisplayProject(
                    projectEntity.title,
                    projectEntity.summary,
                    projectEntity.description,
                    projectEntity.tasks,
                    projectEntity.num_remainingTasks,
                    projectEntity.num_totalTasks,
                    projectEntity.startDate)
            }.also { mappedList ->
                projectEntries.clear()
                projectEntries.addAll(mappedList)
                projectAdapter.notifyDataSetChanged()
            }
            }
        }
    }
    companion object{
        fun newInstance(): ProjectList{
            return ProjectList()
        }
    }
}